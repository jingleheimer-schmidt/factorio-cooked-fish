require("cooked-fish")
require("more-cooked-fish")
require("advanced-cooked-fish")