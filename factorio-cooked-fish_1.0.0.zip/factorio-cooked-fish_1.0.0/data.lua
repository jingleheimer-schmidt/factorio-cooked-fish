
require("data/cooked-fish")
require("data/more-cooked-fish")
require("data/advanced-cooked-fish")
